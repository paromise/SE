/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package se.customs.CustomsUndertaker.UI;

import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.control.Button;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import se.customs.CustomsUndertaker.dao.DeclarationDAO;
import se.customs.CustomsUndertaker.dao.ProductDAO;
import se.customs.CustomsUndertaker.pojo.Declaration;
import se.customs.CustomsUndertaker.pojo.Product;
import se.customs.EconomicMinisRepres.service.LicenseManager;
import se.customs.UIManagement.UIManager;

/**
 * FXML Controller class
 *
 * @author faeze
 */
public class CustomsUndertakerFXMLController implements Initializable {

    /**
     * Initializes the controller class.
     */
    @FXML
    private Button addLicensesBtn;
    
    @FXML
    private Button addProductsBtn;
    
    @FXML    
    private Button submitBtn;
    
    @FXML 
    private Button exitBtn;
    
    @FXML
    private TextField nationalIdTxtFld;
    
    @FXML
    private TextField declDateTxtFld;
    
    @FXML
    private Label errLabel;
    
    @FXML
    private TextField nameTxtFld;
    
    @FXML
    private TextField familyTxtFld;
    
    @FXML
    private TextField totalValTxtFld;
    
    @FXML
    private TextField srcCountryTxtFld;
    
    @FXML
    private ChoiceBox<String> transWayChcBox;
    
    private Declaration decl = null;
    
    private final DeclarationDAO declDao=new DeclarationDAO();
    private final ProductDAO productDao=new ProductDAO();
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
        errLabel.setVisible(false);
        ArrayList<String> transportWays =  new ArrayList<String>();
        transportWays.add("هوایی");
        transportWays.add("زمینی");
        transportWays.add("دریایی");
        ObservableList<String> list = FXCollections.observableArrayList(transportWays);
        transWayChcBox.setItems(list);
    }    
    
    @FXML
    private void handleButtonAction(ActionEvent event) throws IOException {
        errLabel.setVisible(false);
        Button clickedBtn=(Button) event.getSource();
        String clickedBtnId=(String) clickedBtn.getId();
        
        String nationalId=nationalIdTxtFld.getText();
        String name=nameTxtFld.getText();
        String family=familyTxtFld.getText();
        String totalVal=totalValTxtFld.getText();
        String declDate=declDateTxtFld.getText();
        String srcCountry=srcCountryTxtFld.getText();
        String transWay=transWayChcBox.getValue();
       
        
        if(clickedBtnId.equals("addProductsBtn")){
            if(nationalId.equals("") || declDate.equals("") || name.equals("")
                   || family.equals("") || totalVal.equals("") || srcCountry.equals("")
                    ||transWay.equals("")){
               errLabel.setText("* هیچ یک از فیلدها نمیتواند خالی باشد");
               errLabel.setVisible(true);
           }
           else{

               try{
                  
                   decl=declDao.addDeclaration(new Declaration(name,family
                                                   ,nationalId,declDate,Float.parseFloat(totalVal),srcCountry,transWay));
                   if(decl==null){
                       errLabel.setText("*متاسفانه مشکلی هنگام افزودن پیش أمد ");
                       errLabel.setVisible(true);
                   }
                   else{
                       nationalIdTxtFld.setDisable(true);
                       nameTxtFld.setDisable(true);
                       familyTxtFld.setDisable(true);
                       totalValTxtFld.setDisable(true);
                       declDateTxtFld.setDisable(true);
                       srcCountryTxtFld.setDisable(true);
                       transWayChcBox.setDisable(true);
                       UIManager uiManager=new UIManager();
                       uiManager.setupProductsTable(((Node) event.getSource()).getScene().getWindow(),decl.getDeclID());
                   }
                   

               }catch(Exception e){
                   e.printStackTrace();
                   errLabel.setText("* ارزش کل کالاها باید عدد باشد");
                   errLabel.setVisible(true);
               }
            }

        }
        else if(clickedBtnId.equals("addLicensesBtn")){
             if(decl==null){
                errLabel.setText("* باید ابتدا فرم را پر کرده و کالاهای موردنیاز را اضافه کنید");
                errLabel.setVisible(true);
             }
             else{
                 
                ArrayList<Product> prods=productDao.findProductsByDeclId(decl.getDeclID());
                if(prods==null || prods.size()==0){
                    errLabel.setText("* باید ابتدا فرم را پر کرده و کالاهای موردنیاز را اضافه کنید");
                    errLabel.setVisible(true);
                }
                else{
                     for(Product pro : prods){
                    System.out.println(pro.getName());
                }
                LicenseManager LM=new LicenseManager();
                ArrayList<String> requiredLicenses=LM.getRequiredLicenses(prods);
                addProductsBtn.setDisable(true);
                UIManager uiManager=new UIManager();
                uiManager.setupLicensesTable(((Node) event.getSource()).getScene().getWindow(),requiredLicenses);
                }
                 
             }
            
        }
        else if(clickedBtnId.equals("exitBtn")){
            UIManager.setAppScene("login");
        }
        
        else if(clickedBtnId.equals("submitBtn")){
             nationalIdTxtFld.clear();
            nameTxtFld.clear();
            familyTxtFld.clear();
            totalValTxtFld.clear();
            declDateTxtFld.clear();
            srcCountryTxtFld.clear();
            transWayChcBox.clear();
        }

       
    
    }
    
}
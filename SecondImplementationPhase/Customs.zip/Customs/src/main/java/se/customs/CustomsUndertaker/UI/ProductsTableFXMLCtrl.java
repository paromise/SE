/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package se.customs.CustomsUndertaker.UI;

import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableColumn.CellEditEvent;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.control.cell.TextFieldTableCell;
import se.customs.CustomsUndertaker.dao.ProductDAO;
import se.customs.CustomsUndertaker.pojo.Product;
import se.customs.EconomicMinisRepres.dao.RuleDAO;
import se.customs.UIManagement.UIManager;


/**
 *
 * @author faeze
 */
public class ProductsTableFXMLCtrl implements Initializable {
    @FXML
    private Button addBtn;
    
    @FXML
    private TextField nameTxtFld;
    
    
    @FXML
    private TextField weightTxtFld;
    
    @FXML
    private TextField NumTxtFld;
    
    @FXML
    private TextField CompanyTxtFld;
    
    @FXML
    private TextField unitPriceTxtFld;
    
    @FXML
    private TextField prodTypeTxtFld;
   
    @FXML 
    private Label errLabel;
    
    @FXML
    private TableView table;
    
    @FXML
    private TableColumn nameCol;
    
    @FXML
    private TableColumn weightCol;
    
    @FXML
    private TableColumn companyCol;
    
    @FXML
    private TableColumn numCol;
    
    @FXML
    private TableColumn unitPriceCol;
    
    
    
    Integer id;
    
    private final ObservableList<Product> data=FXCollections.observableArrayList();
    private ProductDAO productDao=new ProductDAO();
    private RuleDAO ruleDao = new RuleDAO();
    ArrayList <String> distinctProdTypes=new ArrayList<String>();
    
    /*public ProductsTableFXMLCtrl(String merchantId,String declDate,String srcCountry){
         
        UIManager.setAppScene("productsTabel");
        if(merchantId==null || declDate==null || srcCountry==null){
             errLabel.setText("* ههه");
             errLabel.setVisible(true);
        }
        if(merchantId.equals("") || declDate.equals("") || srcCountry.equals("")){
            errLabel.setText("* هi,i,");
             errLabel.setVisible(true);
        }
        MERCHANTID=merchantId;
        DECLDATE=declDate;
        SRCCOUNTRY=srcCountry;
       
        
        
        
        
        
        
    }*/
    
    public void init_data(int _id){
        id=_id;
        distinctProdTypes=(ArrayList <String>) ruleDao.listProductTypes();
        for(String str : distinctProdTypes){
            System.out.println("!!"+str);
        }
    }

    public ProductsTableFXMLCtrl() {
      // throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
        
       System.out.println("Initializing...");
        
        table.setEditable(true);
        
        nameCol.setCellValueFactory(
                new PropertyValueFactory<Product, String>("name"));
        

        
        weightCol.setCellValueFactory(
                new PropertyValueFactory<Product, String>("weight"));
        
        
        numCol.setCellValueFactory(
                new PropertyValueFactory<Product, String>("number"));
        
        companyCol.setCellValueFactory(
                new PropertyValueFactory<Product, String>("company"));
        
        unitPriceCol.setCellValueFactory(
                new PropertyValueFactory<Product, String>("unitPrice"));
        
        table.setItems(data);
    }    
    
    @FXML
    public void handleButtonAction(ActionEvent event) {
        Button clickedBtn=(Button) event.getSource();
        String clickedBtnId=(String) clickedBtn.getId();
        
        String name = nameTxtFld.getText();
        String proType = prodTypeTxtFld.getText();
        String weight = weightTxtFld.getText();
        String num = NumTxtFld.getText();
        String company=CompanyTxtFld.getText();
        String unitPrice=unitPriceTxtFld.getText();
        
        
        
        float weightVal=0;
        int numVal=0;
        int unitPriceVal=0;
        
        boolean hasErr=false;
        
     

        if(name.equals("") || weight.equals("") || num.equals("") 
               || company.equals("") || unitPrice.equals("") || proType.equals("")){
             errLabel.setText("* هیچ یک از فیلدها نمی تواند خالی باشد");
             errLabel.setVisible(true);
             hasErr=true;
        }
        
        else if(!distinctProdTypes.contains(proType)){
            errLabel.setText("* نوع کالای وارد شده معتبر نیست");
            errLabel.setVisible(true);
            hasErr=true;
        }
        else{
                try{
                    weightVal=Float.parseFloat(weight);
                    numVal=Integer.parseInt(num);
                    unitPriceVal=Integer.parseInt(unitPrice);

                }catch(Exception e){
                    errLabel.setText("* مقدار وزن و تعداد و قیمت واحد باید عدد باشد");
                    errLabel.setVisible(true);
                    hasErr=true;
                }
        }
        
        
        
        
        if(!hasErr){
           
            Product pro=new Product(name,company,weightVal,numVal
                                ,unitPriceVal,id,proType);
            if(productDao.addProduct(pro)==null){
                errLabel.setText("* متاسفانه مشکلی در حین افزودن پیش أمده است");
                errLabel.setVisible(true);
                hasErr=true;
            }
            else{
                errLabel.setVisible(false);
                data.add(pro);
            
                nameTxtFld.clear();
                prodTypeTxtFld.clear();
                weightTxtFld.clear();
                NumTxtFld.clear();
                CompanyTxtFld.clear();
                unitPriceTxtFld.clear();
            }
            
        }
        
        
    }
    
}
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package se.customs.EconomicMinisRepres.pojo;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 *
 * @author faeze
 */
@Entity
@Table(name = "Rule", catalog = "se")

public class Rule {
    @Id
    @GeneratedValue(strategy=GenerationType.IDENTITY) 
    @Column(name="rid", nullable = false)
    private Integer rid;
    
    @Column(name = "prodType", nullable = false)
    private String prodType;
    
    @Column(name = "licType", nullable = false)
    private String licType;

    public Rule(){
        
    }

    public Rule(String prodType, String licType) {
        this.prodType = prodType;
        this.licType = licType;
    }
    
    public Integer getRid() {
        return rid;
    }

    public void setRid(Integer rid) {
        this.rid = rid;
    }

    public String getProdType() {
        return prodType;
    }

    public void setProdType(String prodType) {
        this.prodType = prodType;
    }

    public String getLicType() {
        return licType;
    }

    public void setLicType(String licType) {
        this.licType = licType;
    }
    
    
    
    
}

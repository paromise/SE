/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package se.customs.EconomicMinisRepres.UI;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import se.customs.EconomicMinisRepres.dao.RuleDAO;
import se.customs.EconomicMinisRepres.pojo.Rule;

/**
 *
 * @author faeze
 */
public class EconomicMinisRepresFXMLCtrl implements Initializable {
     @FXML
    private TextField licTypeTxtFld;
    
    @FXML
    private TextField proTypeTxtFld;
    
    @FXML
    private Button addRuleBtn;
    
    @FXML
    private Label errLabel;
    
    @FXML
    private TableView ruleTable;
    
    @FXML
    private TableColumn licTypeCol;
    
    @FXML
    private TableColumn proTypeCol;
 
    private final ObservableList<Rule> data=FXCollections.observableArrayList();
    private final RuleDAO ruleDao=new RuleDAO();
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
        
       System.out.println("Initializing...");
        
        ruleTable.setEditable(true);
        
        licTypeCol.setCellValueFactory(
                new PropertyValueFactory<Rule, String>("prodType"));
        

        
        proTypeCol.setCellValueFactory(
                new PropertyValueFactory<Rule, String>("licType"));
        
        
      
        
        ruleTable.setItems(data);
    }    
    
    @FXML
    public void handleButtonAction(ActionEvent event) {
        errLabel.setVisible(false);
        Button clickedBtn=(Button) event.getSource();
        String clickedBtnId=(String) clickedBtn.getId();
        
        String licType = licTypeTxtFld.getText();
        String proType = proTypeTxtFld.getText();
        
        
        System.out.println(licType);
        System.out.println(proType);
        
 
        
        
        
     

        if(licType.equals("") || proType.equals("")){
             errLabel.setText("* هیچ یک از فیلدها نمی تواند خالی باشد");
             errLabel.setVisible(true);
             
        }
        else{
            Rule rule=new Rule(proType,licType);
            if(ruleDao.addRule(rule)==null){
                errLabel.setText("* متاسفانه مشکلی در حین افزودن پیش أمده است");
                errLabel.setVisible(true);
                
            }
            else{
                errLabel.setVisible(false);
                data.add(rule);
            
                licTypeTxtFld.clear();
                proTypeTxtFld.clear();
          
            }    
        }
        
        
        
        
        
           
            
            
        
        
    }
}

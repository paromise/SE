/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package se.customs.GetLicense.UI;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableColumn.CellEditEvent;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import se.customs.LicenseManagement.dao.LicenseDAO;
import se.customs.LicenseManagement.pojo.License;
import javafx.scene.control.cell.TextFieldTableCell;
import se.customs.LicenseManagement.dao.Product2DAO;
import se.customs.LicenseManagement.pojo.Product2;
/**
 *
 * @author parmiss
 */
public class ProductsTable2FXMLCtrl implements Initializable{

    @FXML
        private TextField nameTxtFld;
    
    @FXML
        private TextField maxWeightTxtFld;
    
    @FXML
        private TextField maxNumTxtFld;
    
    @FXML
        private TextField CompanyTxtFld;
    
    @FXML
        private TextField maxUnitPriceTxtFld;
    
    @FXML
        private Button addBtn;
    
    @FXML
        private Label errLabel;
    
    @FXML
        private TextField minUnitPriceTxtFld;
    
    @FXML
        private TextField minNumTxtFld;
    
    @FXML
        private TextField minWeightTxtFld;
    
    @FXML
    private TableView table;
    
    @FXML
    private TableColumn nameCol;
    
    @FXML
    private TableColumn minWeightCol;
    
    @FXML
    private TableColumn maxWeightCol;
    
    @FXML
    private TableColumn companyCol;
    
    @FXML
    private TableColumn minNumCol;

    @FXML
    private TableColumn maxNumCol;
    
    @FXML
    private TableColumn minUnitPriceCol;
    
    @FXML
    private TableColumn maxUnitPriceCol;
    
    Integer id;
    
    private final ObservableList<Product2> data=FXCollections.observableArrayList();
    private Product2DAO product2Dao=new Product2DAO();
    
    public ProductsTable2FXMLCtrl() {
      // throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
    public void initialize(URL location, ResourceBundle resources) {
        //TODO
        System.out.println("Initializing...");
        
        table.setEditable(true);
        
        nameCol.setCellValueFactory(
                new PropertyValueFactory<Product2, String>("name"));
 
        minWeightCol.setCellValueFactory(
                new PropertyValueFactory<Product2, String>("min_weight"));
        
        maxWeightCol.setCellValueFactory(
                new PropertyValueFactory<Product2, String>("max_weight"));
                
        minNumCol.setCellValueFactory(
                new PropertyValueFactory<Product2, String>("min_number"));
        
        maxNumCol.setCellValueFactory(
                new PropertyValueFactory<Product2, String>("max_number"));
        companyCol.setCellValueFactory(
                new PropertyValueFactory<Product2, String>("company"));
        
        minUnitPriceCol.setCellValueFactory(
                new PropertyValueFactory<Product2, String>("min_unitPrice"));
        
        maxUnitPriceCol.setCellValueFactory(
                new PropertyValueFactory<Product2, String>("max_unitPrice"));
        table.setItems(data);
    }
    
    
    public void init_data(int _id) {
        id = _id;
    }
    
    
    @FXML
    public void handleButtonAction(ActionEvent event) {
        Button clickedBtn=(Button) event.getSource();
        String clickedBtnId=(String) clickedBtn.getId();
        
        String name = nameTxtFld.getText();
    
        String maxWeight = maxWeightTxtFld.getText();
    
        String maxNum = maxNumTxtFld.getText();
   
        String company = CompanyTxtFld.getText();
    
        String maxUnitPrice = maxUnitPriceTxtFld.getText();

        String minWeight = minWeightTxtFld.getText();
    
        String minNum = minNumTxtFld.getText();
        
        String minUnitPrice = minUnitPriceTxtFld.getText();
    
        
        System.out.println(id);
        float maxWeightVal=0;
        float minWeightVal = 0;
        int maxNumVal = 0;
        int minNumVal = 0;
        int maxUnitPriceVal = 0;
        int minUnitPriceVal = 0;
        boolean hasErr = false;
                try{
                    maxWeightVal = Float.parseFloat(maxWeight);
                    minWeightVal = Float.parseFloat(minWeight);
                    maxNumVal = Integer.parseInt(maxNum);
                    minNumVal = Integer.parseInt(minNum);
                    maxUnitPriceVal = Integer.parseInt(maxUnitPrice);
                    minUnitPriceVal = Integer.parseInt(minUnitPrice);
                }catch(Exception e){
                    errLabel.setText("* مقدار وزن و تعداد و قیمت واحد باید عدد باشد");
                    errLabel.setVisible(true);
                    hasErr = true;
                }
        
        
        
        
        if(!hasErr){
           
            Product2 pro=new Product2(name, company, minWeightVal, maxWeightVal, minNumVal, maxNumVal, minUnitPriceVal, maxUnitPriceVal,id);
            if(product2Dao.addProduct(pro)==null){
                errLabel.setText("* متاسفانه مشکلی در حین افزودن پیش أمده است");
                errLabel.setVisible(true);
                hasErr=true;
            }
            else{
                errLabel.setVisible(false);
                data.add(pro);
            
                nameTxtFld.clear();
    
                maxWeightTxtFld.clear();
    
                maxNumTxtFld.clear();
   
                CompanyTxtFld.clear();
    
                maxUnitPriceTxtFld.clear();

                minWeightTxtFld.clear();
    
                minNumTxtFld.clear();
        
                minUnitPriceTxtFld.clear();
            }
            
        }
        
        
    }
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package se.customs.LicenseManagement.UI;

import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableColumn.CellEditEvent;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.control.cell.TextFieldTableCell;
import se.customs.EconomicMinisRepres.service.LicenseManager;
import se.customs.LicenseManagement.dao.LicenseDAO;
import se.customs.LicenseManagement.pojo.License;

/**
 *
 * @author faeze
 */
public class LicenseTableFXMLCtrl implements Initializable {
    
   
    @FXML
    private Label errLabel;
    
    @FXML
    private TableView licTable;
    
    @FXML
    private TableColumn nameCol;
    
    @FXML
    private TableColumn numCol;
    
    String merchantNatId;
    
   
    
    final ObservableList<LicenseTableRow> data=FXCollections.observableArrayList();
    private LicenseDAO licDAO=new LicenseDAO();
    private ArrayList<String> requiredLics=null;
    private LicenseManager LicManager=new LicenseManager();
    
    public void init_data(ArrayList<String> _requiredLics,String _merchantNatId){
       
        merchantNatId=_merchantNatId;
        requiredLics=_requiredLics;
        for(String str: requiredLics){
            data.add(new LicenseTableRow("",str));
        }
    }
    
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
        errLabel.setVisible(false);
        System.out.println("Initializing...");
        licTable.setEditable(true);
        
        
        nameCol.setCellValueFactory(
                new PropertyValueFactory<LicenseTableRow, String>("name"));
        
        numCol.setCellValueFactory(
                new PropertyValueFactory<LicenseTableRow, String>("num"));
        
        numCol.setCellFactory(TextFieldTableCell.forTableColumn());
        numCol.setOnEditCommit(
            new EventHandler<CellEditEvent<LicenseTableRow, String>>() {
                @Override
                public void handle(CellEditEvent<LicenseTableRow, String> t) {
                     errLabel.setVisible(false);
                    try{
                        ((LicenseTableRow) t.getTableView().getItems().get(
                        t.getTablePosition().getRow())
                        ).setNum(t.getNewValue());
                        boolean licValidity=LicManager.check_License_validity(Integer.parseInt(t.getNewValue()),merchantNatId);
                        if(licValidity){
                            errLabel.setText("*چنین مجوزی وجود ندارد ");
                            errLabel.setVisible(true);
                        }
                        else{
                            errLabel.setVisible(false);
                        }
                    }catch(Exception e){
                        errLabel.setText("*چنین مجوزی وجود ندارد ");
                        errLabel.setVisible(true);
                    }
                    
                }
            }
        );
        
        licTable.setItems(data);
        
        
    }
    
    @FXML
    public void handleButtonAction(ActionEvent event) {
        Button clickedBtn=(Button) event.getSource();
        String clickedBtnId=(String) clickedBtn.getId();
        
        /*String licName = licNameTxtFld.getText();
        String licNum = licNumTxtFld.getText();
        
        if( licName.equals("") || licNum.equals("") ){
            errLabel.setText("*هیچ یک از فیلدهای ورودی نمی تواند خالی باشد ");
            errLabel.setVisible(true);
        }
        else{
            try{
                 License lic = licDAO.findLicenseById(Integer.parseInt(licNum));
                 if(lic==null){
                    errLabel.setText("*چنین مجوزی وجود ندارد ");
                    errLabel.setVisible(true);
                 }
                 else{
                    errLabel.setVisible(false);
                    LicenseTableRow ltr=new LicenseTableRow(lic.getLicNum(),lic.getLicName());
                    data.add(ltr);
                    licNameTxtFld.clear();
                    licNumTxtFld.clear();
                 }
            }catch(Exception e){
                errLabel.setText("* شماره مجوز باید عدد باشد");
                errLabel.setVisible(true);
            }
           
        }*/
    }
    
    
}

package se.customs.UsersManagement.dao;

import se.customs.config.HibernateConnector;
import se.customs.UsersManagement.pojo.CustomsUser;
import java.util.List;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

/**
 *
 * @author faeze
 */
public class CustomsUserDAO {
    public CustomsUserDAO(){
        
        CustomsUser user = this.findUserById("CustomsUndertaker");
        if(user==null){
            this.addUser(new CustomsUser("CustomsUndertaker", "123"));
            this.addUser(new CustomsUser("LicenseUndertaker", "234"));
        }
       
        
    }
    public List<CustomsUser> listUser() {
        Session session = null;
        try {
            session = HibernateConnector.getInstance().getSession();
            Query query = session.createQuery("from CustomsUser u");

            List queryList = query.list();
            if (queryList != null && queryList.isEmpty()) {
                return null;
            } else {
                System.out.println("list " + queryList);
                return (List<CustomsUser>) queryList;
            }
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        } finally {
            session.close();
        }
    }

    public CustomsUser findUserById(String username) {
        Session session = null;
        try {
            session = HibernateConnector.getInstance().getSession();
            Query query = session.createQuery("from CustomsUser u where u.username = :username");
            query.setParameter("username", username);

            List queryList = query.list();
            if (queryList != null && queryList.isEmpty()) {
                return null;
            } else {
                return (CustomsUser) queryList.get(0);
            }
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        } finally {
            session.close();
        }
    }

    public void updateUser(CustomsUser user) {
        Session session = null;
        try {
            session = HibernateConnector.getInstance().getSession();
            session.saveOrUpdate(user);
            session.flush();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            session.close();
        }
    }

    public CustomsUser addUser(CustomsUser user) {
        Session session = null;
        Transaction transaction = null;
        try {
            session = HibernateConnector.getInstance().getSession();
            System.out.println("session : "+session);
            transaction = session.beginTransaction();
            session.save(user);
            transaction.commit();
            return user;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        } 
    }

    public void deleteUser(String username) {
        Session session = null;
        try {
            session = HibernateConnector.getInstance().getSession();
            Transaction beginTransaction = session.beginTransaction();
            Query createQuery = session.createQuery("delete from CustomsUser u where u.username =:username");
            createQuery.setParameter("username",username);
            createQuery.executeUpdate();
            beginTransaction.commit();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            session.close();
        }
    }
}

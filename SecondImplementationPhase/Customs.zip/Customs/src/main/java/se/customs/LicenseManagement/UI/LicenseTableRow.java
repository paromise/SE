/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package se.customs.LicenseManagement.UI;

import javafx.beans.property.IntegerProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

/**
 *
 * @author faeze
 */
public class LicenseTableRow {
  

    private final IntegerProperty num;

    private final StringProperty name;

    public LicenseTableRow(int num, String name) {

        this.num = new SimpleIntegerProperty(num);
        this.name = new SimpleStringProperty(name);

    }

    public void setNum(int id) {
        this.num.set(id);
    }

    public void setName(String name) {
        this.name.set(name);
    }

    public int getNum() {
        return num.get();
    }

    public String getName() {
        return name.get();
    }

    public StringProperty nameProperty() {
        return name;
    }

    public IntegerProperty numProperty() {
        return num ;
    }

}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package se.customs.GetLicense.UI;

import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.TextField;
import se.customs.LicenseManagement.dao.LicenseDAO;
import se.customs.LicenseManagement.pojo.License;
import se.customs.UIManagement.UIManager;

/**
 * FXML Controller class
 *
 * @author paromise
 */
public class GetLicenseFXMLController implements Initializable {

    /**
     * Initializes the controller class.
     */
    
    @FXML
    private TextField nationalIdTxtFld;
    
    @FXML
    private TextField licenseTypeTxtFld;
      
    @FXML
    private TextField countryTxtFld;
    
    @FXML
    private ChoiceBox transWayChcBox;
    
    @FXML
    private Button submitBtn;
    
    @FXML
    private Button exitBtn;
    
    @FXML
    private Label errLabel;
    
    @FXML
    private Button addProductsBtn;
    
    @FXML
    private TextField NumTxtFld;
    
    @FXML
    private TextField dueDateTxtFld;
    
    private final LicenseDAO licDao=new LicenseDAO();
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
        ArrayList<String> transportWays =  new ArrayList<String>();
        transportWays.add("هوایی");
        transportWays.add("زمینی");
        transportWays.add("دریایی");
        ObservableList<String> list = FXCollections.observableArrayList(transportWays);
        transWayChcBox.setItems(list);
    }    
    
    @FXML
    private void handleButtonAction(ActionEvent event) throws IOException {
        Button clickedBtn=(Button) event.getSource();
        String clickedBtnId=(String) clickedBtn.getId();
        
        String nationalId=nationalIdTxtFld.getText();
        String ltype = licenseTypeTxtFld.getText();
        String dueDate = dueDateTxtFld.getText();
        String country = countryTxtFld.getText();
        String num = NumTxtFld.getText();
        String transWay=(String) transWayChcBox.getValue();
        
        if(clickedBtnId.equals("submitBtn") || clickedBtnId.equals("addProductsBtn")){
            if(nationalId.equals("") || ltype.equals("")){
               /*myerrLabel.setText("* هیچ یک از فیلدها نمیتواند خالی باشد");
               myerrLabel.setVisible(true);*/
           }
           else{

               try{
                  
                   License lic=licDao.addLicense(new License(nationalId, dueDate, ltype, country, transWay ));
                   if(lic==null){
                       errLabel.setText("*متاسفانه مشکلی هنگام افزودن پیش أمد ");
                       errLabel.setVisible(true);
                   }
                   else{
                       errLabel.setText("*OK");
                       errLabel.setVisible(true);
                   }
                   
                   if(clickedBtnId.equals("addProductsBtn") && lic != null) {
                        UIManager uiManager=new UIManager();
                        uiManager.setupProductsTable2(((Node) event.getSource()).getScene().getWindow(), lic.getLicNum());   
                    }
               }catch(Exception e){
                   e.printStackTrace();
                   //errLabel.setText("* ارزش کل کالاها باید عدد باشد");
                   //errLabel.setVisible(true);
               }
            }
            
        }
        
        
        /*else if(clickedBtnId.equals("exitBtn")){
            UIManager.setAppScene("login");
        }*/
    
    }
    
}

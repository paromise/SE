/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package se.customs.EconomicMinisRepres.service;

import java.util.ArrayList;
import se.customs.CustomsUndertaker.pojo.Product;
import se.customs.EconomicMinisRepres.dao.RuleDAO;
import se.customs.EconomicMinisRepres.pojo.Rule;
import se.customs.LicenseManagement.pojo.License;

/**
 *
 * @author faeze
 */
public class LicenseManager {
    private final RuleDAO ruleDao = new RuleDAO();
    public LicenseManager(){
        
    }
    
    public ArrayList<String> getRequiredLicenses(ArrayList <Product> prods){
     
       
        ArrayList <String> reqLicTypes= new ArrayList <> ();
        for(Product prod : prods){
            ArrayList<Rule> rules=ruleDao.findRulesByProdType(prod.getType());
            for(Rule r : rules){
                System.out.println("*"+r.getLicType());
                if(!reqLicTypes.contains(r.getLicType())){
                  reqLicTypes.add(r.getLicType());
                }
                
            }
        }
        return reqLicTypes;
        
    }
}
